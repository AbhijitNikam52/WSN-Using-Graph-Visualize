<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WSN</title>
    <style>
      * {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
      }
      .chartMenu {
        width: 100vw;
        height: 40px;
        background: #1A1A1A;
        color: rgba(54, 162, 235, 1);
      }
      .chartMenu p {
        padding: 10px;
        font-size: 20px;
      }
      .chartCard {
        width: 100vw;
        height: calc(100vh - 40px);
        background: rgba(54, 162, 235, 0.2);
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .chartBox {
        width: 1200px;
        height: 600px;
        padding: 20px;
        border-radius: 20px;
        border: solid 3px rgba(54, 162, 235, 1);
        background: white;
        padding-bottom: 30px;
      }
    </style>
  </head>
  <body>
    <div class="chartMenu">
      <p align="center">GRAPH VISUALIZE USING WSN</p>
    </div>
    <div class="chartCard">
      <div class="chartBox">
        <canvas id="myChart"></canvas>
        <button onclick="download()">Download</button>
      </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.2/d3.min.js" integrity="sha512-oKI0pS1ut+mxQZdqnD3w9fqArLyILRsT3Dx0B+8RVEXzEk3aNK3J3pWlaGJ8MtTs1oiwyXDAH6hG6jy1sY0YqA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.umd.min.js"></script>
    <script>

      const testData='http://localhost/Project/data1.csv';

      //parse the file from csv to json
      
      d3.csv(testData).then(function(datapoints)
      {
        console.log(datapoints);
        const sort_id = [];
        const date_d_m_y = [];
        const time = []; 
        const sensor_id = [];
        const sensor_type = [];
        const temp_C = [];
        const hpa_div_4 = [];
        const batterylevel = [];
        const sensor_cycle = [];

        for(i=0;i<datapoints.length;i++)
        {
            sort_id.push(datapoints[i].sort_id)
            date_d_m_y.push(datapoints[i].date_d_m_y)
            time.push(datapoints[i].time)
            sensor_id.push(datapoints[i].sensor_id)
            sensor_type.push(datapoints[i].sensor_type)
            temp_C.push(datapoints[i].temp_C)
            hpa_div_4.push(datapoints[i].hpa_div_4)
            batterylevel.push(datapoints[i].batterylevel)
            sensor_cycle.push(datapoints[i].sensor_cycle)
        }

        const data = {
      labels: ['1','3','126','20','23','31','38','45','48','56','61','67','70','78','84','87','90','95','97','101','105','106','110','112','118','123','126','128','132','135','138','143','151','153','158','162','168','171','176','178','184','187','191','194','197','203','206','211','214','220','222','224','230','233','236','239','249','257','260','263','271','277','281','282','286','289','294','298','303','305','308','310','315','323','332','337','339','340','346','348','351','354','360','364','373','377','392','397','402','404','405','408','409','410','419','421','424','428','430','432','434','441','444','448','452','454','457','461','464','471','474','482','485','490','491','492','497','500'],
      datasets: [{
        label: 'sensor',
        data: sensor_id,
        backgroundColor: [
          'rgba(255, 26, 104, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(0, 0, 0, 0.2)'
        ],
        borderColor: [
          'rgba(255, 26, 104, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(0, 0, 0, 1)'
        ],
        borderWidth: 1
      }]
    };

    // config 
    const config = {
      type: 'line',
      data,
      options: {
        scales: {
          y: {
            beginAtZero: false

          }
        }
      }
    };

    // render init block
    const myChart = new Chart(
      document.getElementById('myChart'),
      config
    );

    // Instantly assign Chart.js version
    const chartVersion = document.getElementById('chartVersion');
    chartVersion.innerText = Chart.version;

      });

      function download(){
        const imageLink=document.createElement('a');
        const canvas = document.getElementById('myChart');
        imageLink.download = 'canvas.png';
        imageLink.href = canvas.toDataURL('image/png', 1);
        //window.open(imageLink);
        //document.write('img src=" ' +imageLink+ ' "/>');

        //console.log(imageLink.href);
        imageLink.click();
      }
    </script>

  </body>
</html>