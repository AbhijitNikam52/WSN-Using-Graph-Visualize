<!DOCTYPE html>
<html>
    <head>
        <title>Image</title>
        <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    </style>
    </head>
    <body>
        <center><h2 style="color:orange;">Select The Graph Image</h2></center>
        <br>
        <br>
        <br>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="uploadfile"/>
            <input type="submit" name="uploadfilesub" value="upload"/>
            </body>

</html>



<?php 
$conn = mysqli_connect("localhost","root","","uploadfile");
if($conn)
{
    echo "</br>";  
    echo "</br>";  
    echo " connected ";
}

    if(isset($_POST['uploadfilesub']))
    {
        $filename = $_FILES['uploadfile']['name'];
        $filetmpname = $_FILES['uploadfile']['tmp_name'];
        $folder ='imagesuploaded/';

        move_uploaded_file($filetmpname, $folder.$filename);

    $sql = "INSERT into uploadedimage(imagename) VALUES('$filename')";

    //$sql = "INSERT INTO 'uploadedimage' ('imagename') VALUES ('$filename')";

    //$qry = mysqli_query($conn, $sql);

    if(mysqli_query($conn,$sql))
    {
        echo "</br>";  
        echo "</br>";  
        echo " image uploaded ";
    }

    /*if($qry)
    {
        echo "image uploaded";
    }*/
}


?>
